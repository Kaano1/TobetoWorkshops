package com.tobeto.spring1b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring1bApplicationTests {

	@Test
	void contextLoads() {
	}

}
