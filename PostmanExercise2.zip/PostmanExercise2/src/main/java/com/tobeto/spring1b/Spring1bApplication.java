package com.tobeto.spring1b;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring1bApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring1bApplication.class, args);
	}

}
